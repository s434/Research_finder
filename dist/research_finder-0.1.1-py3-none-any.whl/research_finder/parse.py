# import xml.etree.ElementTree as ET
# import re
# from typing import List, Dict, Tuple

# NON_ACADEMIC_KEYWORDS = ["Inc.", "Ltd.", "Biotech", "Pharmaceuticals", "Corp.", "Genomics"]

# def parse_papers(xml_data: str) -> List[Dict]:
#     """Parses PubMed XML response and extracts relevant details."""
#     root = ET.fromstring(xml_data)
#     papers = []

#     for article in root.findall(".//PubmedArticle"):
#         pubmed_id = article.find(".//PMID").text if article.find(".//PMID") is not None else "N/A"
#         title = article.find(".//ArticleTitle").text if article.find(".//ArticleTitle") is not None else "N/A"
#         pub_date = article.find(".//PubDate/Year")
#         pub_date = pub_date.text if pub_date is not None else "N/A"

#         authors, companies = extract_authors(article)
#         corresponding_email = extract_corresponding_email(article)

#         papers.append({
#             "PubmedID": pubmed_id,
#             "Title": title,
#             "Publication Date": pub_date,
#             "Non-academic Author(s)": ", ".join(authors),
#             "Company Affiliation(s)": ", ".join(companies),
#             "Corresponding Author Email": corresponding_email
#         })

#     return papers

# def extract_authors(article) -> Tuple[List[str], List[str]]:
#     """Identifies non-academic authors based on affiliation."""
#     authors = []
#     companies = []

#     for author in article.findall(".//Author"):
#         affil = author.find(".//Affiliation")
#         if affil is not None:
#             affiliation = affil.text
#             if any(keyword in affiliation for keyword in NON_ACADEMIC_KEYWORDS):
#                 authors.append(author.find("LastName").text if author.find("LastName") is not None else "Unknown")
#                 companies.append(affiliation)

#     return authors, companies

# def extract_corresponding_email(article) -> str:
#     """Extracts the corresponding author's email."""
#     emails = re.findall(r"[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}", ET.tostring(article, encoding="unicode"))
#     return emails[0] if emails else "N/A"

import xml.etree.ElementTree as ET
import re
from typing import List, Dict, Tuple

NON_ACADEMIC_KEYWORDS = ["Inc.", "Ltd.", "Biotech", "Pharmaceuticals", "Corp.", "Genomics"]

def parse_papers(xml_data: str) -> List[Dict]:
    """Parses PubMed XML response and extracts relevant details, handling missing data."""
    if not xml_data:
        return []  # Avoid parsing empty data
    
    try:
        root = ET.fromstring(xml_data)
        papers = []

        for article in root.findall(".//PubmedArticle"):
            pubmed_id = get_text(article, ".//PMID")
            title = get_text(article, ".//ArticleTitle")
            pub_date = get_text(article, ".//PubDate/Year")

            authors, companies = extract_authors(article)
            corresponding_email = extract_corresponding_email(article)

            papers.append({
                "PubmedID": pubmed_id,
                "Title": title,
                "Publication Date": pub_date,
                "Non-academic Author(s)": ", ".join(authors) if authors else "N/A",
                "Company Affiliation(s)": ", ".join(companies) if companies else "N/A",
                "Corresponding Author Email": corresponding_email
            })

        return papers
    
    except ET.ParseError as e:
        print(f"Error parsing XML: {e}")
        return []  # Return empty list instead of crashing

def get_text(element, path: str) -> str:
    """Helper function to safely extract text from an XML element."""
    found = element.find(path)
    return found.text.strip() if found is not None and found.text else "N/A"

def extract_authors(article) -> Tuple[List[str], List[str]]:
    """Identifies non-academic authors based on affiliation."""
    authors = []
    companies = []

    for author in article.findall(".//Author"):
        affil = author.find(".//Affiliation")
        if affil is not None:
            affiliation = affil.text.strip() if affil.text else "N/A"
            if any(keyword in affiliation for keyword in NON_ACADEMIC_KEYWORDS):
                last_name = author.find("LastName")
                authors.append(last_name.text if last_name is not None else "Unknown")
                companies.append(affiliation)

    return authors, companies

def extract_corresponding_email(article) -> str:
    """Extracts the corresponding author's email."""
    try:
        emails = re.findall(r"[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}", ET.tostring(article, encoding="unicode"))
        return emails[0] if emails else "N/A"
    except Exception as e:
        print(f"Error extracting email: {e}")
        return "N/A"
